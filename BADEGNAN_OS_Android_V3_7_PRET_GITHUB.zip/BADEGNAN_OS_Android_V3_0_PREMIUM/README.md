# BADEGNAN OS Android 3.7

**Clean GitHub development baseline**

BADEGNAN OS is being developed first as a clean Android project. APK generation is handled later by GitHub Actions.

## Workflow

1. Modify and verify the source code.
2. Push the repository to GitHub.
3. GitHub Actions runs the Android build and Lint.
4. Download the generated APK from the workflow artifact.
5. Test the APK on a real Android device before release.

## Local development

Open the project in Android Studio and synchronize the Gradle project.

## Repository hygiene

Do not commit:
- `local.properties`
- signing keys (`.jks`, `.keystore`)
- generated `build/` directories
- API keys or passwords

## Current version

**3.7.0**
