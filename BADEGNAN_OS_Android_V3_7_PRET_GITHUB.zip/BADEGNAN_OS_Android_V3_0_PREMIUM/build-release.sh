#!/usr/bin/env bash
set -euo pipefail

if command -v ./gradlew >/dev/null 2>&1 && [ -x ./gradlew ]; then
  ./gradlew clean lintRelease assembleRelease
else
  gradle clean lintRelease assembleRelease
fi

echo "Release APK:"
ls -lh app/build/outputs/apk/release/*.apk
