# Gradle Wrapper setup

This project archive did not contain a Gradle Wrapper.
Open the project in Android Studio, or from a machine with Gradle installed run:

    gradle wrapper

Then commit:
- gradlew
- gradlew.bat
- gradle/wrapper/gradle-wrapper.jar
- gradle/wrapper/gradle-wrapper.properties

After that, GitHub Actions will build the project with ./gradlew.
