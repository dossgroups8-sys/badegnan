#!/usr/bin/env python3
"""Fast static verification for BADEGNAN OS Android project."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
errors=[]; warnings=[]

def need(path):
    if not (ROOT/path).exists(): errors.append(f"missing: {path}")

for p in [Path('settings.gradle'), Path('build.gradle'), Path('app/build.gradle'), Path('app/src/main/AndroidManifest.xml'), Path('app/src/main/java/com/badegnan/os/MainActivity.java')]: need(p)
for p in [Path('app/src/main/AndroidManifest.xml'), Path('app/src/main/res/layout/activity_main.xml'), Path('app/src/main/res/values/styles.xml')]:
    try: ET.parse(ROOT/p)
    except Exception as e: errors.append(f"XML invalid: {p}: {e}")
html=(ROOT/'app/src/main/assets/index.html').read_text(errors='replace')
for ref in re.findall(r'(?:src|href)=["\']([^"\']+)["\']', html):
    if ref.startswith('./') and not ref.startswith('./http'):
        p=ROOT/'app/src/main/assets'/ref[2:]
        if not p.exists() and not ref.startswith('./#'): warnings.append(f"asset reference not found: {ref}")
# Java balance (rough structural check)
j=(ROOT/'app/src/main/java/com/badegnan/os/MainActivity.java').read_text()
clean=re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', '', j, flags=re.S)
if clean.count('{') != clean.count('}'): errors.append('Java brace imbalance')
if clean.count('(') != clean.count(')'): errors.append('Java parenthesis imbalance')
# Ensure no release secrets tracked in project tree
for pat in ('*.jks','*.keystore','local.properties'):
    if list(ROOT.rglob(pat)): errors.append(f"secret/build-local file present: {pat}")
print('BADEGNAN OS static verification')
print('ERRORS:', len(errors))
for x in errors: print('  ERROR', x)
print('WARNINGS:', len(warnings))
for x in warnings[:20]: print('  WARN', x)
if errors: sys.exit(1)
print('STATUS: PASS (static checks)')
