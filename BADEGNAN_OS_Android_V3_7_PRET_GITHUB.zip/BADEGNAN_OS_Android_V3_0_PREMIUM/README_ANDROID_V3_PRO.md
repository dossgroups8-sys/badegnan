# BADEGNAN OS 3.0 — édition haut de gamme

Version Android professionnelle du Centre de Commande BADEGNAN OS.

## Nouveautés 3.0
- Identité visuelle premium vert profond / or.
- Écran de lancement natif modernisé.
- Navigation et cartes avec profondeur visuelle, états de focus et micro-interactions.
- Interface mobile plus lisible et plus tactile.
- Indication native du mode hors ligne / retour réseau.
- Pont Android → interface Web pour signaler l’état natif et la version 3.0.
- Gestion WebView renforcée : JavaScript, stockage local, Safe Browsing et sélecteur de fichiers.
- Conservation du fonctionnement hors ligne et de la synchronisation Supabase existante.
- Version applicative : 3.0.0 (code 30).

## Compilation
Le dépôt est prêt à être ouvert dans Android Studio avec Gradle/AGP compatible avec le projet.

```bash
./gradlew assembleDebug
```

Si le wrapper Gradle n’est pas présent dans votre copie, ouvrez le projet dans Android Studio puis utilisez la synchronisation Gradle.
